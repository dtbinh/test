# -*- coding: utf-8 -*-

ACCESS_KEY = ""
SECRET_KEY = ""

RS_HOST = "rs.qbox.me"
RSF_HOST = "rsf.qbox.me"
UP_HOST = "up.qiniu.com"

from . import __version__
USER_AGENT = "qiniu python-sdk v%s" % __version__

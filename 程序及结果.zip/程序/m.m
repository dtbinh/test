for i=28:41
    str = int2str(i) ;
    pic = imread([str '.png']) ;
    pic = rgb2gray(pic) ;
    imwrite(pic,[str '.jpg']) ;
end
    
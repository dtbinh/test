#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<windows.h>
#include<math.h>
#include<cv.h>
#include<cxcore.h>
#include<highgui.h>
#include<cvcam.h>

int main()
{
	int i ;
	int h ;
	long t ;
	double scale=1 ;
	char ch =0 ;
	char str[80] ;
	char str0[80] ;

	cvNamedWindow( "lena" , CV_WINDOW_AUTOSIZE ) ;
	CvMemStorage *storage=cvCreateMemStorage(0) ;
	CvHaarClassifierCascade *cascade = (CvHaarClassifierCascade *)cvLoad( "face.xml" , 0, 0, 0 ) ;

	for(int j=1 ; j<=220 ; j++ )
	{
		itoa( j,str ,10 ) ;
		strcat(str,".jpg") ;
		IplImage *image = cvLoadImage(str);
		CvSeq *faces ;

		//cvResize( gray , smal , CV_INTER_LINEAR ) ;
		//cvEqualizeHist( image , image ) ;
		//cvShowImage( "lena" , image ) ;

		t = GetTickCount() ;
		faces = cvHaarDetectObjects( image , cascade , storage , 1.1 ,2 ,CV_HAAR_DO_CANNY_PRUNING ,cvSize(6,6) ) ;
		t = GetTickCount() - t ;

		printf("%4d time: %ldms\n" ,j, t ) ;
		
		if( faces->total>0 )
			printf("**************************YES!****************************\n");
		for( i=0 ; i<faces->total ; i++ )
		{
			CvRect *face_rect = (CvRect *)cvGetSeqElem( faces,i ) ;
			cvRectangle(image,cvPoint(face_rect->x,face_rect->y),cvPoint( face_rect->x+face_rect->width , face_rect->y+face_rect->height),CV_RGB(255,0,0),3 ) ;
		}

		cvShowImage( "lena" , image ) ;
		ch = cvWaitKey(500) ;
		if( ch==' ' )
		{	break ;	}
		strcpy(str,"���\\") ;
		itoa(j,str0,10) ;
		strcat(str0,".jpg") ;
		strcat(str,str0) ;
		cvSaveImage(str,image) ;
		cvReleaseImage(&image) ;
	}
	
	cvReleaseHaarClassifierCascade( &cascade ) ;
	cvDestroyWindow("lena") ;
	
	return 0;
}